
# Fleet Platform

## Features
- Dual stream ingestion (Meter & Vehicle)
- Hot/Cold storage
- PostgreSQL
- Analytics endpoint

## Run
docker-compose up --build

## Endpoint
POST /v1/ingest/meter
POST /v1/ingest/vehicle
GET /v1/analytics/performance/:vehicleId
